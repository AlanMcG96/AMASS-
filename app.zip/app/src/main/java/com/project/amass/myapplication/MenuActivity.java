package com.project.amass.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.Button;

public class MenuActivity extends AppCompatActivity {
    private Button btn_track_car, btn_shutdown_car;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        btn_track_car = (Button)findViewById(R.id.track_car);
        btn_shutdown_car = (Button)findViewById(R.id.shutdown_car);

        btn_track_car.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MenuActivity.this, GoogleMapActivity.class));
                finish();

            }
        });

        btn_shutdown_car.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MenuActivity.this, ShutdownCarActivity.class));
                finish();

            }
        });
    }
}
