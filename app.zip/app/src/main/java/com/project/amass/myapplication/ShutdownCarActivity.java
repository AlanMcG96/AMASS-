package com.project.amass.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class ShutdownCarActivity extends AppCompatActivity {
    private Button btn_confirm_shutdown;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shutdown_car);

        btn_confirm_shutdown = (Button)findViewById(R.id.shutdown_car);

        btn_confirm_shutdown.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(ShutdownCarActivity.this, "Vehicle has been shutdown",Toast.LENGTH_SHORT).show();

            }
        });


    }
}
